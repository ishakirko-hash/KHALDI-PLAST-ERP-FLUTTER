package dz.khaldiplast.erp.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF082F6F)
val Blue = Color(0xFF078EF4)
val Cyan = Color(0xFF19C7F5)
val Green = Color(0xFF12B981)
val Orange = Color(0xFFFFA323)
val Red = Color(0xFFFF4F68)
val Purple = Color(0xFF8655F5)
val GlassWhite = Color(0xDDF7FCFF)
val SoftBlue = Color(0xFF4776A7)

@Composable
fun KpTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            secondary = Cyan,
            background = Color(0xFFE8F5FF),
            surface = Color(0xFFF4FAFF),
            onPrimary = Color.White,
            onSurface = Ink,
            onBackground = Ink
        ),
        content = content
    )
}
