package dz.khaldiplast.erp.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Product(val id: Long, val code: String, val name: String, val category: String, val stock: Int, val unit: String, val size: String, val image: String, val color: String)
data class Invoice(val id: Long, val number: String, val customer: String, val date: String, val total: Long, val status: String, val productName: String, val quantity: Int)
data class ProductionEntry(val id: Long, val date: String, val product: String, val machine: String, val quantity: Int, val status: String)
data class NoteEntry(val id: Long, val customer: String, val product: String, val quantity: Int, val dueDate: String, val status: String, val details: String)
data class DashboardTotals(val sales: Long, val production: Int, val stock: Int, val rawStock: Int, val expenses: Long, val invoiceCount: Int, val lowStock: Int)
data class Employee(val id: Long, val name: String, val role: String, val shift: String, val status: String)
data class SalesPoint(val month: String, val amount: Float)

class ErpDatabase(context: Context) : SQLiteOpenHelper(context, "khaldi_plast_fresh.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT, category TEXT, stock INTEGER DEFAULT 0, unit TEXT, size TEXT, image TEXT, color TEXT)")
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT, customer TEXT, date TEXT, total INTEGER, status TEXT, productName TEXT, quantity INTEGER)")
        db.execSQL("CREATE TABLE production(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, product TEXT, machine TEXT, quantity INTEGER, status TEXT)")
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT, product TEXT, quantity INTEGER, dueDate TEXT, status TEXT, details TEXT)")
        db.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount INTEGER, date TEXT)")
        db.execSQL("CREATE TABLE employees(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, role TEXT, shift TEXT, status TEXT DEFAULT 'غائب')")
        val seed = listOf(
            arrayOf("CP9", "الصندوق CP9", "صناديق", "0", "قطعة", "90 × 300 × 500 مم", "crate_blue", "أزرق"),
            arrayOf("CP14", "الصندوق CP14", "صناديق", "0", "قطعة", "140 × 300 × 500 مم", "crate_green", "أخضر"),
            arrayOf("SIP14", "Sipora 14", "صناديق", "0", "قطعة", "140 × 300 × 400 مم", "crate_black", "أسود"),
            arrayOf("SIP20", "Sipora 20", "صناديق", "0", "قطعة", "200 × 300 × 400 مم", "crate_blue", "أزرق"),
            arrayOf("RM001", "حبيبات أولية (Granulé)", "مواد خام", "0", "كغ", "مواد بوليمر خام", "pellets_blue", "أزرق"),
            arrayOf("RM002", "مادة مكسرّة (Broyé)", "مواد خام", "0", "كغ", "مواد معاد طحنها", "regrind_white", "أبيض"),
            arrayOf("RM003", "إضافات (Additifs)", "مواد خام", "0", "كغ", "إضافات إنتاج", "regrind_white", "أبيض")
        )
        seed.forEach { a ->
            val cv = ContentValues().apply { put("code", a[0]); put("name", a[1]); put("category", a[2]); put("stock", a[3].toInt()); put("unit", a[4]); put("size", a[5]); put("image", a[6]); put("color", a[7]) }
            db.insert("products", null, cv)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun products(): List<Product> {
        val out = mutableListOf<Product>()
        readableDatabase.rawQuery("SELECT * FROM products ORDER BY id", null).use { c ->
            while (c.moveToNext()) out += Product(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getInt(4), c.getString(5), c.getString(6), c.getString(7), c.getString(8))
        }
        return out
    }
    fun totals(): DashboardTotals {
        val db = readableDatabase
        fun scalar(sql: String): Long = db.rawQuery(sql, null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
        return DashboardTotals(scalar("SELECT COALESCE(SUM(total),0) FROM invoices"), scalar("SELECT COALESCE(SUM(quantity),0) FROM production").toInt(), scalar("SELECT COALESCE(SUM(stock),0) FROM products WHERE category = 'صناديق'").toInt(), scalar("SELECT COALESCE(SUM(stock),0) FROM products WHERE category = 'مواد خام'").toInt(), scalar("SELECT COALESCE(SUM(amount),0) FROM expenses"), scalar("SELECT COUNT(*) FROM invoices").toInt(), scalar("SELECT COUNT(*) FROM products WHERE category = 'صناديق' AND stock < 100").toInt())
    }

    fun monthlySales(): List<SalesPoint> {
        val out = mutableListOf<SalesPoint>()
        readableDatabase.rawQuery("SELECT substr(date,1,7) AS month, SUM(total) FROM invoices GROUP BY substr(date,1,7) ORDER BY month DESC LIMIT 6", null).use { c ->
            while (c.moveToNext()) out += SalesPoint(c.getString(0), c.getFloat(1))
        }
        return out.reversed()
    }

    fun invoices(): List<Invoice> {
        val out = mutableListOf<Invoice>()
        readableDatabase.rawQuery("SELECT id,number,customer,date,total,status,productName,quantity FROM invoices ORDER BY id DESC LIMIT 30", null).use { c ->
            while (c.moveToNext()) out += Invoice(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4), c.getString(5), c.getString(6), c.getInt(7))
        }
        return out
    }
    fun production(): List<ProductionEntry> {
        val out = mutableListOf<ProductionEntry>()
        readableDatabase.rawQuery("SELECT id,date,product,machine,quantity,status FROM production ORDER BY id DESC LIMIT 30", null).use { c ->
            while (c.moveToNext()) out += ProductionEntry(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getInt(4), c.getString(5))
        }
        return out
    }
    fun notes(): List<NoteEntry> {
        val out = mutableListOf<NoteEntry>()
        readableDatabase.rawQuery("SELECT id,customer,product,quantity,dueDate,status,details FROM notes ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out += NoteEntry(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getString(4), c.getString(5), c.getString(6))
        }
        return out
    }
    fun addProduction(productId: Long, quantity: Int, machine: String, shift: String) {
        require(quantity > 0) { "يجب أن تكون الكمية أكبر من صفر" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val p = products().firstOrNull { it.id == productId } ?: error("المنتج غير موجود")
            require(p.category == "صناديق") { "الإنتاج متاح للمنتجات النهائية فقط" }
            db.insert("production", null, ContentValues().apply { put("date", today()); put("product", p.name); put("machine", machine); put("quantity", quantity); put("status", "مكتمل") })
            db.execSQL("UPDATE products SET stock = stock + ? WHERE id = ?", arrayOf(quantity, productId))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun adjustStock(productId: Long, delta: Int) {
        val p = products().firstOrNull { it.id == productId } ?: error("المنتج غير موجود")
        require(p.stock + delta >= 0) { "لا يمكن أن يصبح المخزون سالباً" }
        writableDatabase.execSQL("UPDATE products SET stock = stock + ? WHERE id = ?", arrayOf(delta, productId))
    }
    fun addInvoice(customer: String, productId: Long, quantity: Int, unitPrice: Long, status: String) {
        require(customer.isNotBlank()) { "أدخل اسم العميل" }; require(quantity > 0 && unitPrice >= 0) { "تحقق من الكمية والسعر" }
        val p = products().firstOrNull { it.id == productId } ?: error("المنتج غير موجود")
        require(p.category == "صناديق") { "يمكن إصدار فاتورة للمنتجات النهائية فقط" }
        require(p.stock >= quantity) { "المخزون غير كافٍ. المتاح: ${p.stock}" }
        val db = writableDatabase; db.beginTransaction()
        try {
            val number = "KP-${System.currentTimeMillis().toString().takeLast(7)}"
            db.insert("invoices", null, ContentValues().apply { put("number", number); put("customer", customer.trim()); put("date", today()); put("total", quantity * unitPrice); put("status", status); put("productName", p.name); put("quantity", quantity) })
            db.execSQL("UPDATE products SET stock = stock - ? WHERE id = ?", arrayOf(quantity, productId))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun addNote(customer: String, productId: Long, quantity: Int, dueDate: String, details: String) {
        require(customer.isNotBlank()) { "أدخل اسم العميل" }; require(quantity > 0) { "أدخل كمية صحيحة" }
        val p = products().firstOrNull { it.id == productId } ?: error("المنتج غير موجود")
        require(p.category == "صناديق") { "الطلبيات يجب أن تكون لمنتج نهائي" }
        writableDatabase.insert("notes", null, ContentValues().apply { put("customer", customer.trim()); put("product", p.name); put("quantity", quantity); put("dueDate", dueDate); put("status", "بانتظار التنفيذ"); put("details", details) })
    }
    fun markNote(id: Long, status: String) { writableDatabase.execSQL("UPDATE notes SET status=? WHERE id=?", arrayOf(status, id)) }

    fun employees(): List<Employee> {
        val out = mutableListOf<Employee>()
        readableDatabase.rawQuery("SELECT id,name,role,shift,status FROM employees ORDER BY name", null).use { c ->
            while (c.moveToNext()) out += Employee(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4))
        }
        return out
    }
    fun addEmployee(name: String, role: String, shift: String) {
        require(name.isNotBlank()) { "أدخل اسم العامل" }
        writableDatabase.insert("employees", null, ContentValues().apply { put("name", name.trim()); put("role", role.trim()); put("shift", shift); put("status", "غائب") })
    }
    fun setEmployeeStatus(id: Long, status: String) {
        require(status in listOf("حاضر", "غائب", "راحة"))
        writableDatabase.execSQL("UPDATE employees SET status=? WHERE id=?", arrayOf(status, id))
    }

    fun addExpense(title: String, amount: Long) {
        require(title.isNotBlank() && amount > 0) { "أدخل وصفاً ومبلغاً صحيحاً" }
        writableDatabase.insert("expenses", null, ContentValues().apply { put("title", title); put("amount", amount); put("date", today()) })
    }
}
