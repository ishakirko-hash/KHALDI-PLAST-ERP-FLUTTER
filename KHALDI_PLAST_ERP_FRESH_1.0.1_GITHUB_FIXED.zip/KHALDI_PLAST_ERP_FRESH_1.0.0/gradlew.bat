@echo off
setlocal
set APP_HOME=%~dp0
set VERSION=8.9
set DIST=%USERPROFILE%\.gradle\kp-bootstrap\gradle-%VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%USERPROFILE%\.gradle\kp-bootstrap" mkdir "%USERPROFILE%\.gradle\kp-bootstrap"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%USERPROFILE%\.gradle\kp-bootstrap\gradle-%VERSION%-bin.zip'; Expand-Archive -Force '%USERPROFILE%\.gradle\kp-bootstrap\gradle-%VERSION%-bin.zip' '%USERPROFILE%\.gradle\kp-bootstrap'"
  if errorlevel 1 exit /b 1
)
call "%DIST%\bin\gradle.bat" -p "%APP_HOME%" %*
exit /b %errorlevel%
